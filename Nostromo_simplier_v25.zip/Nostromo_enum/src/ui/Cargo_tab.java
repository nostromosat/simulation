package ui;

public class Cargo_tab {

}
